export class Cour {
    id!: number;
    name!: string;
    programme!: string;
}