export class Registration {
    id!: number;
    details!: string;
    studentName!: string;
    courName!: string;
    year!: string;
}