export class Year {
    id!: number;
    name!: string;
}
