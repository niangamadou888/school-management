import { Component } from '@angular/core';

@Component({
  selector: 'app-update-year',
  standalone: true,
  imports: [],
  templateUrl: './update-year.component.html'
})
export class UpdateYearComponent {

}
