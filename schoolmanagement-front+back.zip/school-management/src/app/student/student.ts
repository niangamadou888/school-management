export class Student {
    id!: number;
    firstName!: string;
    lastName!: string;
    birthdate!: Date;
    phone!: number;
}
